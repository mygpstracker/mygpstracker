// ------ Setup the map: ------

var map = L.map('map').setView([39.8282, -95.5795],5);  //default center and zoom level
map.attributionControl.setPrefix('<a href="http://www.mygpstracker.xyz" target="blank"><img src="./assets/img/gpstracker_logo.png"></a></img>');

// ------ Define the markers: ------

 var trackerMarker = L.AwesomeMarkers.icon({
    prefix: 'fa',
    icon: 'car',
    iconColor: 'white', 
    //spin: 'true',
    markerColor: 'blue'
  });

// ------ Realtime Tracker: ------

var MyTrack = L.realtime({
    url: "./getlastlocations.php",
    crossOrigin: false,
    detectRetina: true,
    type: 'json'
  }, { interval: 30 * 1000}).addTo(map);

MyTrack.on('update', function(e) {
    popupContent = function(fId) {
        var feature = e.features[fId];
        var gpsTime = new Date(feature.properties.gpsTime + "Z");
        var gpsTimeLocal = gpsTime.toLocaleString();
        var content = '<h3><u><font color="#2680C9">' +feature.properties.userName +' Information <\/h3><\/u><\/font>' +
        '<b>User Name:</b> ' + feature.properties.userName + '<br \/>' +
        '<b>Phone ID:</b> ' + feature.properties.phoneNumber + '<br \/>' +
        '<b>Location Accuracy:</b> ' + feature.properties.accuracy + 'ft.<br \/>' +
        '<b>GPS Time:</b> ' + gpsTimeLocal + '<\/p>';   
        return content;
    },
    bindFeaturePopup = function(fId) {
        MyTrack.getLayer(fId).bindPopup(popupContent(fId));
        MyTrack.getLayer(fId).bindTooltip('<font color="#2680C9">' +e.features[fId].properties.userName+ '<\/font>');
        MyTrack.getLayer(fId).setIcon(trackerMarker);
    },
    updateFeaturePopup = function(fId) {
        MyTrack.getLayer(fId).getPopup().setContent(popupContent(fId));
    };
    Object.keys(e.enter).forEach(bindFeaturePopup);
    Object.keys(e.update).forEach(updateFeaturePopup);
});


// ------ Basemap Definitions: ------
var streets = L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png').addTo(map);
var cycle = L.tileLayer('http://{s}.tile.opencyclemap.org/cycle/{z}/{x}/{y}.png');
var topo = L.tileLayer('http://server.arcgisonline.com/ArcGIS/rest/services/NatGeo_World_Map/MapServer/tile/{z}/{y}/{x}');

var baseMaps = {
    "Open Street Map": streets,
    "Open Cycle Map": cycle,
    "World Topo Map": topo
};
var overlays = {
    "My Track": MyTrack
};

// ------ Layer Control: ------
L.control.layers(baseMaps,overlays).addTo(map);
