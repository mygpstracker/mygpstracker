<?php
    include 'dbconnect.php';
    
    // ------ Form and exeucte SQL to get last reported locations: ------
    //  note: the grouping/filtering is done on username
    $sql = "SELECT gpslocations.userName, gpslocations.* 
            FROM   gpslocations, 
                  (SELECT max(gpslocations.gpslocationid) AS lastlocationid, gpslocations.username
                   FROM gpslocations
                   GROUP BY gpslocations.username) lastlocation
            WHERE gpslocations.gpslocationid = lastlocation.lastlocationid;";

    switch ($dbType) {
        case DB_MYSQL:
        case DB_POSTGRESQL:
        case DB_SQLITE3:
            $stmt = $pdo->prepare($sql);
            break;
    }

    $stmt->execute();
    
    
    // ------ Format the data as GeoJSON: ------
    // GeoJSON preamble:
    $json = '{"type": "FeatureCollection", 
              "crs": { 
                  "type": "name", 
                  "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } 
              },
              "features": [';

    // GeoJSON for each record:
    foreach ($stmt as $row) {
        $json .= '{"type": "Feature", 
                   "properties": {
                      "id":"' . $row['userName'] . '", 
                      "lastUpdate":"'     . $row['lastUpdate']  . '",
                      "phoneNumber":"'    . $row['phoneNumber'] . '",
                      "userName":"'       . $row['userName'] . '",
                      "sessionID":"'      . $row['sessionID'] . '",
                      "speed":"'          . $row['speed'] . '",
                      "direction":"'      . $row['direction'] . '",
                      "distance":"'       . $row['distance'] . '",
                      "gpsTime":"'        . $row['gpsTime'] . '",
                      "locationMethod":"' . $row['locationMethod'] . '",
                      "accuracy":"'       . $row['accuracy'] . '",
                      "extraInfo":"'      . $row['extraInfo'] . '",
                      "eventType":"'      . $row['eventType'] . '"
                   },
                   "geometry":{ "type": "Point", "coordinates": [' . $row['longitude'] . ',' . $row['latitude'] . ']}
                  }';
                 
//        $json .= $row['geojson'];
        $json .= ',';
    };
   
    // Close the GeoJSON:
    $json = rtrim($json, ",");
    $json .= ']} ';
    
    header("Access-Control-Allow-Origin: *");
    header('Content-Type: application/json');
    echo $json;
?>